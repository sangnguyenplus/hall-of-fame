<!-- Facebook Pixel fix must load before any other scripts -->
<script src="{{ asset('vendor/core/plugins/hall-of-fame/js/fb-pixel-fix.js') }}"></script>
