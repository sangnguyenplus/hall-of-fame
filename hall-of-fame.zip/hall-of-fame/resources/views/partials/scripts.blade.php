<!-- Hall of Fame plugin scripts -->
<script src="{{ asset('vendor/core/plugins/hall-of-fame/js/hall-of-fame.js') }}"></script>
